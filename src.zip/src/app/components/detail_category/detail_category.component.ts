import { Component, OnInit } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'app-detail_category',
  templateUrl: './detail_category.component.html',
  styleUrls: ['./detail_category.component.css']
})
export class DetailCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

