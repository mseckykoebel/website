import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-license-info',
  templateUrl: './image-license-info.component.html',
  styleUrls: ['./image-license-info.component.css']
})
export class ImageLicenseInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

