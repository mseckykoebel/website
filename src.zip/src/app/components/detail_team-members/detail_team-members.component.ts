import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail_team-members',
  templateUrl: './detail_team-members.component.html',
  styleUrls: ['./detail_team-members.component.css']
})
export class DetailTeamMembersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

