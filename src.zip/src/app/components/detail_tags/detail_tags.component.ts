import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail_tags',
  templateUrl: './detail_tags.component.html',
  styleUrls: ['./detail_tags.component.css']
})
export class DetailTagsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

