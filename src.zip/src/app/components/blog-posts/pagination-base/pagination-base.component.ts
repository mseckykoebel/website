import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagination-base',
  templateUrl: './pagination-base.component.html',
  styleUrls: ['./pagination-base.component.css']
})
export class PaginationBaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

