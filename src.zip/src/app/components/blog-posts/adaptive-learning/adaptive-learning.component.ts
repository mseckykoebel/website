import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adaptive-learning',
  templateUrl: './adaptive-learning.component.html',
  styleUrls: ['./adaptive-learning.component.css']
})
export class AdaptiveLearningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

