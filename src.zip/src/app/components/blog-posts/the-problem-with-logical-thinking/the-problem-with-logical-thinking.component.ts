import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-the-problem-with-logical-thinking',
  templateUrl: './the-problem-with-logical-thinking.component.html',
  styleUrls: ['./the-problem-with-logical-thinking.component.css']
})
export class TheProblemWithLogicalThinkingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

