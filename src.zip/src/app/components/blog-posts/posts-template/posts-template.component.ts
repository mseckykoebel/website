import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-posts-template',
  templateUrl: './posts-template.component.html',
  styleUrls: ['./posts-template.component.css']
})
export class PostsTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

