import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adaptive-learning-the-good-and-the-conclusion',
  templateUrl: './adaptive-learning-the-good-and-the-conclusion.component.html',
  styleUrls: ['./adaptive-learning-the-good-and-the-conclusion.component.css']
})
export class AdaptiveLearningTheGoodAndTheConclusionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

