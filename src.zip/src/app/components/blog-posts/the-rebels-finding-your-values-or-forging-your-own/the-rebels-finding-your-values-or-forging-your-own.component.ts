import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-the-rebels-finding-your-values-or-forging-your-own',
  templateUrl: './the-rebels-finding-your-values-or-forging-your-own.component.html',
  styleUrls: ['./the-rebels-finding-your-values-or-forging-your-own.component.css']
})
export class TheRebelsFindingYourValuesOrForgingYourOwnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

