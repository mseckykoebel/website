import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adaptive-learning-the-data',
  templateUrl: './adaptive-learning-the-data.component.html',
  styleUrls: ['./adaptive-learning-the-data.component.css']
})
export class AdaptiveLearningTheDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

