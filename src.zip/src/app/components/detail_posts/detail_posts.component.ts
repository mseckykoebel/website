import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail_posts',
  templateUrl: './detail_posts.component.html',
  styleUrls: ['./detail_posts.component.css']
})
export class DetailPostsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

